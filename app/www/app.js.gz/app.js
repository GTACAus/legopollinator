'use strict';
/* The Pollination Problem: iPad remote for the robot pollinator. Talks to the LMS-ESP32 board (see README.md).
Motors: C right wheel, D left wheel, E the pollination arm.
Blockly (blockly.js, with blocks.js inside) is loaded only when the code canvas is needed. */
const MOTORS = 'BCDEF';
const DRIVE = 'drive';               // an axis that drives both wheels: up / down = C and D, left / right = pivot on one wheel
const $ = (id) => document.getElementById(id);
const AXES = { dpad: ['Up / down', 'Left / right'], slider: ['Up / down'], joy: ['Up / down', 'Left / right'], button: ['Button'] };
const KIND = { dpad: 'D-pad', slider: 'Slider', joy: 'Joystick', button: 'Button' };
const MAX_WIDGETS = 5;
const store = {
get(k, d) { try { const v = sessionStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (_) { return d; } },
set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (_) {} }
};
/* x, y: where a control sits on the board, as a fraction of the room it has to move in
(0 = left / top edge, 1 = right / bottom edge), so a control never hangs off the board. */
function defaults() {
return [{ n: 1, t: 'dpad', x: 0.3, y: 0.5, ax: [{ m: DRIVE, rev: false, sp: 2 }, { m: DRIVE, rev: false, sp: 2 }] },
{ n: 2, t: 'slider', x: 0.7, y: 0.5, ax: [{ m: 'E', rev: false, sp: 2 }] }];
}
const S = {
tab: 'remote',                  // the only tab
sub: store.get('pol-sub', 'basic'),
layout: (() => { const l = store.get('pol-remote-v1', null); return Array.isArray(l) && l.length ? l : defaults(); })(),
editing: false,
outs: {},                       // control number -> [axis 0, axis 1], signed speed level -3..3
prog: [0, 0, 0, 0, 0],          // Advanced mode: run state digits set by the program
pos: [-1, -1, -1, -1, -1], base: [-1, -1, -1, -1, -1],
hubMode: 0, mask: 31
};
const saveLayout = () => store.set('pol-remote-v1', S.layout);
/* ================= link to the board ================= */
const Link = {
ws: null, open: false, busy: false, dirty: false, lastRx: 0,
connect() {
try { this.ws = new WebSocket('ws://' + location.host + '/ws'); } catch (_) { setTimeout(() => this.connect(), 3000); return; }
this.ws.onopen = () => { this.open = true; this.send(); };
this.ws.onmessage = (e) => this.receive(String(e.data));
this.ws.onclose = () => { this.open = false; setTimeout(() => this.connect(), 1500); };
this.ws.onerror = () => { try { this.ws.close(); } catch (_) {} };
},
message(extra) {
let m = 'x=1&m=' + digits();
return extra ? m + '&' + extra : m;
},
send(extra) {
const msg = this.message(extra);
if (this.open) { try { this.ws.send(msg); return; } catch (_) { this.open = false; } }
if (this.busy) { this.dirty = true; if (extra) this.pending = extra; return; }
this.busy = true; this.dirty = false;
fetch('/s?' + msg, { cache: 'no-store' }).then((r) => r.text()).then((t) => this.receive(t))
.catch(() => {}).finally(() => {
this.busy = false;
if (this.dirty) { const p = this.pending; this.pending = null; this.send(p); }
});
},
receive(text) {
// Only the board's own replies count as connected: on another network, /s can still get an
// answer (a router's page, a captive portal) and the page would look connected when it isn't.
if (!/^[pbh] /m.test(text)) return;
this.lastRx = performance.now();
for (const line of text.split('\n')) {
const f = line.trim().split(' ');
if ((f[0] === 'p' || f[0] === 'b') && f.length > 2) {
const i = MOTORS.indexOf(f[1]);
if (i >= 0) { (f[0] === 'p' ? S.pos : S.base)[i] = +f[2]; motorsDirty = true; }
} else if (f[0] === 'h' && f.length > 3) {
S.hubMode = +f[1]; S.mask = +f[3]; motorsDirty = true;
}
}
}
};
function linkState() {
const age = performance.now() - Link.lastRx;
const el = $('link');
if (age < 2500) { el.textContent = Link.open ? 'Connected' : 'Connected (slow)'; el.className = 'pill' + (Link.open ? '' : ' slow'); }
else { el.textContent = 'Not connected – check Wi-Fi'; el.className = 'pill off'; }
}
/* Run state digit per motor: 0 stop, 1-3 forward, 4-6 back */
function digits() {
if (S.tab !== 'remote') return '00000';
if (S.sub === 'advanced') return S.prog.join('');
const lv = [0, 0, 0, 0, 0];
for (const w of S.layout) {
const o = S.outs[w.n] || [];
w.ax.forEach((a, i) => {
const v = (a.rev ? -1 : 1) * (o[i] || 0);
if (a.m === DRIVE) {                 // the wheels: up / down both, left / right just one (a pivot turn)
if (AXES[w.t][i] !== 'Left / right') { lv[1] += v; lv[2] += v; }
else if (v < 0) lv[1] -= v;          // left: motor C drives forward
else lv[2] += v;                     // right: motor D drives forward
return;
}
const k = MOTORS.indexOf(a.m); if (k >= 0) lv[k] += v;
});
}
return lv.map((l) => { l = Math.max(-3, Math.min(3, l)); return l >= 0 ? l : 3 - l; }).join('');
}
let toastTimer = 0;
function toast(text) {
const s = $('status'); s.textContent = text; s.classList.add('show');
clearTimeout(toastTimer); toastTimer = setTimeout(() => s.classList.remove('show'), 2200);
}
/* ================= the remote's controls ================= */
function zone(v, sp) {                  // how far a slider or stick is pushed -> speed level
const a = Math.abs(v); if (a < 0.2) return 0;
const l = 1 + Math.min(sp - 1, Math.floor(Math.min(1, (a - 0.2) / 0.8) * sp));
return v < 0 ? -l : l;
}
function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; }
/* Which directions of control n are held: {up, down, left, right, pressed} */
function heldOf(w) {
const o = S.outs[w.n] || [0, 0], h = {};
if (w.t === 'button') { if (o[0]) h.pressed = true; return h; }
if (o[0] > 0) h.up = true; if (o[0] < 0) h.down = true;
if (o[1] > 0) h.right = true; if (o[1] < 0) h.left = true;
return h;
}
function setOut(w, i, v) {
const o = S.outs[w.n] || (S.outs[w.n] = [0, 0]);
if (o[i] === v) return;
const before = heldOf(w);
o[i] = v;
if (S.sub === 'basic') Link.send();
else if (window.Program) window.Program.control(w.n, before, heldOf(w));
motorsDirty = true;
}
function active() { return !S.editing && S.tab === 'remote'; }
function pointerHold(node, onDown, onMove, onUp) {
let id = null;
node.addEventListener('pointerdown', (e) => {
if (!active()) return;
e.preventDefault(); id = e.pointerId;
try { node.setPointerCapture(e.pointerId); } catch (_) {}
onDown(e);
});
node.addEventListener('pointermove', (e) => { if (e.pointerId === id) onMove(e); });
['pointerup', 'pointercancel', 'lostpointercapture'].forEach((n) =>
node.addEventListener(n, (e) => { if (e.pointerId === id) { id = null; onUp(e); } }));
}
function buildDpad(w) {
const box = el('div', 'dpad');
box.innerHTML = '<svg viewBox="0 0 200 200"><circle cx="100" cy="100" r="100" fill="#4C34E5"/>' +
'<rect class="arm V" x="68" y="14" width="64" height="172" rx="32"/><rect class="arm H" x="14" y="68" width="172" height="64" rx="32"/>' +
'<path class="arrow U" d="M100 30 L114 52 L86 52 Z"/><path class="arrow D" d="M100 170 L114 148 L86 148 Z"/>' +
'<path class="arrow L" d="M30 100 L52 86 L52 114 Z"/><path class="arrow R" d="M170 100 L148 86 L148 114 Z"/></svg>';
const q = (s) => box.querySelector(s);
const paint = () => {
const o = S.outs[w.n] || [0, 0];
q('.U').classList.toggle('on', o[0] > 0); q('.D').classList.toggle('on', o[0] < 0);
q('.R').classList.toggle('on', o[1] > 0); q('.L').classList.toggle('on', o[1] < 0);
q('.V').classList.toggle('on', o[0] !== 0); q('.H').classList.toggle('on', o[1] !== 0);
};
const at = (e) => {
const r = box.getBoundingClientRect(), R = r.width / 2;
const dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R), d = Math.hypot(dx, dy);
let up = 0, side = 0;
if (d > 0.2 * R) { if (Math.abs(dy) > 0.38 * d) up = dy < 0 ? 1 : -1; if (Math.abs(dx) > 0.38 * d) side = dx > 0 ? 1 : -1; }
setOut(w, 0, up * w.ax[0].sp); setOut(w, 1, side * w.ax[1].sp); paint();
};
pointerHold(box, at, at, () => { setOut(w, 0, 0); setOut(w, 1, 0); paint(); });
return box;
}
function buildSlider(w) {
const track = el('div', 'track'), handle = el('div', 'handle', '<i></i><i></i>');
track.appendChild(handle);
const at = (e) => {
const r = track.getBoundingClientRect(), half = (r.height - handle.offsetHeight) / 2;
const off = Math.max(-half, Math.min(half, e.clientY - (r.top + r.height / 2)));
handle.classList.remove('back'); handle.style.top = (r.height / 2 + off) + 'px';
const l = zone(-off / half, w.ax[0].sp); setOut(w, 0, l); handle.classList.toggle('on', l !== 0);
};
pointerHold(track, at, at, () => { handle.classList.add('back'); handle.style.top = '50%'; setOut(w, 0, 0); handle.classList.remove('on'); });
return track;
}
function buildJoy(w) {
const base = el('div', 'joy'), knob = el('div', 'knob');
base.appendChild(knob);
const at = (e) => {
const r = base.getBoundingClientRect(), R = r.width / 2, lim = R * 0.62;
let dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R); const d = Math.hypot(dx, dy);
if (d > lim) { dx *= lim / d; dy *= lim / d; }
knob.classList.remove('back'); knob.style.left = (R + dx) + 'px'; knob.style.top = (R + dy) + 'px';
const a = zone(-dy / lim, w.ax[0].sp), b = zone(dx / lim, w.ax[1].sp);
setOut(w, 0, a); setOut(w, 1, b); knob.classList.toggle('on', a !== 0 || b !== 0);
};
pointerHold(base, at, at, () => { knob.classList.add('back'); knob.style.left = '50%'; knob.style.top = '50%'; setOut(w, 0, 0); setOut(w, 1, 0); knob.classList.remove('on'); });
return base;
}
function buildButton(w) {
const b = el('button', 'btn'); b.textContent = w.name || 'Hold';
pointerHold(b, () => { b.classList.add('on'); setOut(w, 0, w.ax[0].sp); }, () => {}, () => { b.classList.remove('on'); setOut(w, 0, 0); });
return b;
}
const BUILD = { dpad: buildDpad, slider: buildSlider, joy: buildJoy, button: buildButton };
function caption(w) {
const names = [...new Set(w.ax.filter((a) => a.m).map((a) => a.m === DRIVE ? 'Wheels C + D' : 'Motor ' + a.m))];
if (w.t === 'button') return (w.name || 'Button') + (names.length ? ' · ' + names[0] : '');
return names.join(' · ') || 'No motor chosen';
}
function render() {
const board = $('board');
board.innerHTML = '';
S.layout.forEach((w, idx) => {
S.outs[w.n] = [0, 0];
const box = el('div', 'wgt');
box.appendChild(el('div', 'num', String(w.n)));
box.appendChild(BUILD[w.t](w));
box.appendChild(el('div', 'cap', S.sub === 'advanced' ? KIND[w.t] + ' ' + w.n : caption(w)));
const tools = el('div', 'tools');
[['⚙', 'set', 'Settings'], ['✕', 'del', 'Remove']].forEach(([txt, act, label]) => {
const b = el('button', null, txt); b.setAttribute('aria-label', label);
b.addEventListener('click', () => tool(act, idx)); tools.appendChild(b);
});
box.appendChild(tools);
dragToMove(box, w);
board.appendChild(box);
});
place();
document.querySelectorAll('#editbar [data-add]').forEach((b) => { b.disabled = S.layout.length >= MAX_WIDGETS; });
Link.send();
}
function tool(act, idx) {
const L = S.layout, w = L[idx];
if (act === 'del') L.splice(idx, 1);
else if (act === 'set') { openSettings(w); return; }
saveLayout(); render();
}
function addWidget(t) {
if (S.layout.length >= MAX_WIDGETS) return;
const usedN = new Set(S.layout.map((w) => w.n));
let n = 1; while (usedN.has(n)) n++;
const used = new Set(S.layout.flatMap((w) => w.ax.flatMap((a) => a.m === DRIVE ? ['C', 'D'] : [a.m])));
const free = MOTORS.split('').filter((m) => !used.has(m));
const ax = AXES[t].map((_, i) => ({ m: free[i] || '', rev: false, sp: t === 'slider' || t === 'joy' ? 3 : 2 }));
S.layout.push({ n, t, ax, name: t === 'button' ? 'Hold' : '' });     // no x, y yet: place() finds it a spot
render(); saveLayout();
}
/* ================= the board as a canvas: controls sit where they are dragged ================= */
const GAP = 10;                                      // px kept between controls
const onCanvas = () => !$('previewBoard').contains($('board'));   // in the code canvas they just line up
function room(box) {                                 // how far a control can move: [x, y] in px
const b = $('board');
return [Math.max(0, b.clientWidth - box.offsetWidth), Math.max(0, b.clientHeight - box.offsetHeight)];
}
function rectAt(box, x, y) {
const [rx, ry] = room(box);
return { l: x * rx, t: y * ry, r: x * rx + box.offsetWidth, b: y * ry + box.offsetHeight };
}
const overlap = (a, b) => a.l < b.r + GAP && b.l < a.r + GAP && a.t < b.b + GAP && b.t < a.b + GAP;
function clashes(box, x, y) {                        // would this control at (x, y) touch another one?
const me = rectAt(box, x, y);
return [...$('board').children].some((o) => o !== box && o.dataset.placed && overlap(me, rectAt(o, +o.dataset.x, +o.dataset.y)));
}
function freeSpot(box, tidy) {                       // a clear spot for this control, or null if none
// Candidates: tidy spots (tidy: none), then hard against each placed control's edges, which
// finds any gap that is wide enough, however narrow.
const [rx, ry] = room(box), w = box.offsetWidth, h = box.offsetHeight;
const xs = tidy ? [0] : [0, 0.25 * rx, 0.5 * rx, 0.75 * rx, rx], ys = tidy ? [0] : [0.5 * ry, 0, ry];
for (const o of $('board').children) {
if (o === box || !o.dataset.placed) continue;
const r = rectAt(o, +o.dataset.x, +o.dataset.y);
xs.push(r.r + GAP, r.l - GAP - w); ys.push(r.t, r.b + GAP, r.t - GAP - h);
}
if (tidy) { xs.sort((a, b) => a - b); ys.sort((a, b) => a - b); }
for (const y of ys) for (const x of xs) {
if (x < 0 || x > rx + 0.5 || y < 0 || y > ry + 0.5) continue;
const fx = rx ? Math.min(1, x / rx) : 0, fy = ry ? Math.min(1, y / ry) : 0;
if (!clashes(box, fx, fy)) return [fx, fy];
}
return null;
}
function setAt(box, x, y) {
const [rx, ry] = room(box);
box.style.left = (x * rx) + 'px'; box.style.top = (y * ry) + 'px';
box.dataset.x = x; box.dataset.y = y; box.dataset.placed = '1';
}
function place() {
const boxes = [...$('board').children];
if (!onCanvas()) { boxes.forEach((b) => { b.style.left = b.style.top = ''; delete b.dataset.placed; }); return; }
if (!$('board').clientWidth) return;                // hidden (another tab): placed when shown
let moved = false, full = false;
boxes.forEach((b) => delete b.dataset.placed);
S.layout.forEach((w, i) => {
const box = boxes[i]; if (!box) return;
if (typeof w.x !== 'number' || typeof w.y !== 'number') {
const spot = freeSpot(box);
if (!spot) { full = true; return; }
[w.x, w.y] = spot; moved = true;
}
setAt(box, Math.max(0, Math.min(1, w.x)), Math.max(0, Math.min(1, w.y)));
});
if (full) {                                       // no room left: line every control up in rows
boxes.forEach((b) => delete b.dataset.placed);
S.layout.forEach((w, i) => {
const box = boxes[i]; if (!box) return;
[w.x, w.y] = freeSpot(box, true) || [0.5, 0.5];   // rows, from the top left
setAt(box, w.x, w.y);
});
moved = true;
toast('Tidied the controls to make room');
}
if (moved) saveLayout();
}
function dragToMove(box, w) {
let drag = null;
box.addEventListener('pointerdown', (e) => {
if (!S.editing || !onCanvas() || e.target.closest('.tools')) return;
e.preventDefault();
try { box.setPointerCapture(e.pointerId); } catch (_) {}
drag = { id: e.pointerId, x0: e.clientX, y0: e.clientY, l: box.offsetLeft, t: box.offsetTop, fx: w.x, fy: w.y };
box.classList.add('lift');
});
box.addEventListener('pointermove', (e) => {
if (!drag || e.pointerId !== drag.id) return;
const [rx, ry] = room(box);
const l = Math.max(0, Math.min(rx, drag.l + e.clientX - drag.x0)), t = Math.max(0, Math.min(ry, drag.t + e.clientY - drag.y0));
box.style.left = l + 'px'; box.style.top = t + 'px';
box.classList.toggle('clash', clashes(box, rx ? l / rx : 0, ry ? t / ry : 0));
});
const drop = (e) => {
if (!drag || e.pointerId !== drag.id) return;
const [rx, ry] = room(box), x = rx ? box.offsetLeft / rx : 0, y = ry ? box.offsetTop / ry : 0;
box.classList.remove('lift', 'clash');
if (clashes(box, x, y)) { setAt(box, drag.fx, drag.fy); toast('No room there: controls can’t overlap'); }
else { w.x = x; w.y = y; setAt(box, x, y); saveLayout(); }
drag = null;
};
box.addEventListener('pointerup', drop);
box.addEventListener('pointercancel', drop);
}
window.addEventListener('resize', place);
function openSettings(w) {
const box = $('dlgbox'); box.innerHTML = '';
box.appendChild(el('h2', null, KIND[w.t] + ' ' + w.n + ': choose the motors'));
if (w.t === 'button') {
const d = el('div', 'ax', '<b>Name on the button</b>');
const i = el('input'); i.type = 'text'; i.maxLength = 10; i.value = w.name || '';
i.addEventListener('input', () => { w.name = i.value; saveLayout(); });
d.appendChild(i); box.appendChild(d);
}
w.ax.forEach((a, i) => {
const d = el('div', 'ax'); d.appendChild(el('b', null, AXES[w.t][i]));
const sel = el('select');
sel.innerHTML = '<option value="">No motor</option><option value="' + DRIVE + '"' + (a.m === DRIVE ? ' selected' : '') + '>Wheels (C + D)</option>' + MOTORS.split('').map((m) => '<option value="' + m + '"' + (a.m === m ? ' selected' : '') + '>Motor ' + m + '</option>').join('');
sel.addEventListener('change', () => { a.m = sel.value; saveLayout(); });
const sp = el('select'), analog = w.t === 'slider' || w.t === 'joy';
sp.innerHTML = [['Slow', 1], ['Medium', 2], ['Fast', 3]].map(([n, v]) => '<option value="' + v + '"' + (a.sp === v ? ' selected' : '') + '>' + (analog ? 'Top speed: ' : 'Speed: ') + n + '</option>').join('');
sp.addEventListener('change', () => { a.sp = +sp.value; saveLayout(); });
const rev = el('label', null, '<input type="checkbox"' + (a.rev ? ' checked' : '') + '> Turn the other way');
rev.firstChild.addEventListener('change', (e) => { a.rev = e.target.checked; saveLayout(); });
d.appendChild(sel); d.appendChild(document.createTextNode(' ')); d.appendChild(sp);
const row = el('div'); row.appendChild(rev); d.appendChild(row);
box.appendChild(d);
});
const done = el('button', 'done', 'Done');
done.addEventListener('click', () => { $('dlg').classList.remove('open'); render(); });
box.appendChild(done);
$('dlg').classList.add('open');
}
/* ================= motors: live positions and homes ================= */
let motorsDirty = true;
function drawMotors() {
if (!motorsDirty) return;
motorsDirty = false;
const d = digits();
for (const strip of [$('motorStrip'), $('motorStrip2')]) {
if (!strip.children.length) {
for (const m of MOTORS) strip.appendChild(el('div', 'mtile', '<b>' + m + '</b><div><div class="deg">–</div><div class="home">home –</div></div>'));
}
[...strip.children].forEach((t, i) => {
t.classList.toggle('none', !(S.mask & (1 << i)));
t.classList.toggle('run', d[i] !== '0');
t.querySelector('.deg').textContent = S.pos[i] >= 0 ? S.pos[i] + '°' : '–';
t.querySelector('.home').textContent = 'home ' + (S.base[i] >= 0 ? S.base[i] + '°' : '–');
});
}
}
/* ================= tabs, modes and buttons ================= */
function show() {
const adv = S.sub === 'advanced';
$('sBasic').classList.toggle('sel', !adv); $('sAdvanced').classList.toggle('sel', adv);
document.body.classList.toggle('advanced', adv);
$('homeBtn').classList.toggle('hide', adv); $('editBtn').classList.toggle('hide', adv);
$('codeBtn').classList.toggle('hide', !adv);
$('modeHint').textContent = S.editing ? 'Drag a control to move it. ⚙ sets it up, ✕ removes it (up to 5). Tap ✎ again when you are done.'
: adv ? 'Advanced: your code is always running here, so the controls do what your code says. Open the code canvas to change it.'
: 'Basic: hold a control to move. The d-pad drives the wheels (C and D), the slider moves the arm (E). ⌂ Home returns the arm to its home position.';
runButtons();
place();
keepRunning();
}
function runButtons() {
const running = !!(window.Program && window.Program.running), b = $('runBtn2');
b.textContent = running ? '■ Stop' : '▶ Run'; b.classList.toggle('go', !running); b.classList.toggle('stop', running);
}
/* On the Advanced remote page (not the code canvas) there is no Run button: the program always runs. */
const alwaysOn = () => S.tab === 'remote' && S.sub === 'advanced' && !$('code').classList.contains('open') && !document.hidden;
function keepRunning() {
if (window.Program) window.Program.always = alwaysOn();
if (!alwaysOn()) return;
loadBlockly().then(() => {
window.Program.always = alwaysOn();
if (alwaysOn() && !window.Program.running) { window.Program.start(); runButtons(); }
}).catch(() => {});
}
function setSub(sub) {
if (sub === S.sub) return;
stopProgram();
if (S.editing) toggleEdit();
S.sub = sub; store.set('pol-sub', sub);
S.prog = [0, 0, 0, 0, 0];
for (const k in S.outs) S.outs[k] = [0, 0];
Link.send('c=stop');                     // safety: every motor stops before control changes hands
render(); show();
if (sub === 'advanced') loadBlockly();
toast(sub === 'advanced' ? 'Advanced: your code is in control' : 'Basic: the remote is in control');
}
function toggleEdit() {
S.editing = !S.editing;
for (const k in S.outs) S.outs[k] = [0, 0];
document.body.classList.toggle('editing', S.editing);
$('editBtn').classList.toggle('sel', S.editing);
Link.send(); show();
}
function stopProgram() { if (window.Program && window.Program.running) window.Program.stop(); }
/* ================= Blockly (loaded on demand) ================= */
let blocklyLoading = null;
function loadBlockly() {
if (window.Program) return Promise.resolve();
if (!blocklyLoading) {
blocklyLoading = new Promise((ok, fail) => {
const s = document.createElement('script'); s.src = 'blockly.js?v=3b4e7e13';   // version: set by tools/make_www.py
s.onload = () => ok(); s.onerror = () => { blocklyLoading = null; fail(); };
document.head.appendChild(s);
});
}
return blocklyLoading;
}
/* What the blocks can do: everything goes through the board to the hub */
window.Arm = {
run(k, forward, level) { const i = MOTORS.indexOf(k); if (i >= 0) { S.prog[i] = forward ? level : 3 + level; motorsDirty = true; Link.send(); } },
stop(k) { const i = MOTORS.indexOf(k); if (i >= 0) { S.prog[i] = 0; motorsDirty = true; Link.send(); } },
goTo(k, angle, dir, level) {
const i = MOTORS.indexOf(k); if (i < 0) return;
S.prog[i] = 0;
Link.send('c=go&k=' + k + '&a=' + (((Math.round(angle) % 360) + 360) % 360) + '&d=' + dir + '&v=' + (level - 1));
},
turn(k, degrees, level) {
const i = MOTORS.indexOf(k); if (i < 0) return;
S.prog[i] = 0;
Link.send('c=turn&k=' + k + '&g=' + Math.round(degrees) + '&v=' + (level - 1));
},
drive(way, degrees, level) {          // both wheels together: way = f, b, l, r; degrees each wheel turns
S.prog[1] = S.prog[2] = 0; motorsDirty = true;
Link.send('c=drive&w=' + way + '&g=' + Math.round(Math.abs(degrees)) + '&v=' + (level - 1));
},
home() { S.prog = [0, 0, 0, 0, 0]; Link.send('c=home'); },
stopAll() { S.prog = [0, 0, 0, 0, 0]; motorsDirty = true; Link.send('c=stop'); },
position(k) { const i = MOTORS.indexOf(k); return i >= 0 && S.pos[i] >= 0 ? S.pos[i] : 0; },
held(n, dir) { const w = S.layout.find((x) => x.n === n); return !!(w && heldOf(w)[dir]); },
changed() { runButtons(); }
};
function openCode() {
$('code').classList.add('open');
if (window.Program) window.Program.always = false;  // here Run / Stop is the student's choice
$('previewBoard').appendChild($('board'));          // the same live controls, smaller
$('previewBoard').classList.add('mini');
place();
motorsDirty = true;
loadBlockly().then(() => { $('blocklyLoading').style.display = 'none'; window.Program.show($('blockly')); })
.catch(() => { $('blocklyLoading').textContent = 'Could not load the blocks. Check the Wi-Fi and try again.'; });
}
function closeCode() {
$('code').classList.remove('open');
$('boardHome').appendChild($('board'));
$('previewBoard').classList.remove('mini');
place();
if (window.Program) window.Program.save();
keepRunning();
}
function toggleSide() {
const hide = !$('code').classList.contains('noside');
$('code').classList.toggle('noside', hide); store.set('pol-noside', hide);
$('sideBtn').textContent = hide ? 'Show remote' : 'Hide remote';
window.dispatchEvent(new Event('resize'));        // Blockly fills the space
}
function resetCode() {
if (!confirm('Put the code canvas back how it started? Your blocks will be cleared.')) return;
loadBlockly().then(() => { window.Program.reset(); runButtons(); toast('Code canvas reset'); })
.catch(() => toast('Could not load the blocks'));
}
function runOrStop() {
loadBlockly().then(() => {
if (window.Program.running) { window.Program.stop(); toast('Program stopped'); }
else { window.Program.start(); toast('Program running'); }
runButtons();
}).catch(() => toast('Could not load the blocks'));
}
/* ================= wiring ================= */
$('sBasic').addEventListener('click', () => setSub('basic'));
$('sAdvanced').addEventListener('click', () => setSub('advanced'));
$('homeBtn').addEventListener('click', () => { Link.send('c=home'); toast('Going home'); });
$('editBtn').addEventListener('click', toggleEdit);
$('codeBtn').addEventListener('click', openCode);
$('closeCode').addEventListener('click', closeCode);
$('runBtn2').addEventListener('click', runOrStop);
$('sideBtn').addEventListener('click', toggleSide);
$('resetCode').addEventListener('click', resetCode);
if (store.get('pol-noside', false)) { $('code').classList.add('noside'); $('sideBtn').textContent = 'Show remote'; }
$('helpBtn').addEventListener('click', () => $('help').classList.add('open'));
$('closeHelp').addEventListener('click', () => $('help').classList.remove('open'));
$('reset').addEventListener('click', () => { if (confirm('Go back to the starting remote?')) { S.layout = defaults(); saveLayout(); render(); } });
document.querySelectorAll('[data-add]').forEach((b) => b.addEventListener('click', () => addWidget(b.dataset.add)));
/* iPad: never zoom (double-tap or pinch), no long-press menus */
let lastTouch = 0;
document.addEventListener('touchend', (e) => {
const n = Date.now(); if (n - lastTouch < 350 && !e.target.closest('select,input,#blockly')) e.preventDefault(); lastTouch = n;
}, { passive: false });
document.addEventListener('dblclick', (e) => { if (!e.target.closest('#blockly')) e.preventDefault(); }, { passive: false });
['gesturestart', 'gesturechange', 'gestureend'].forEach((n) => document.addEventListener(n, (e) => e.preventDefault(), { passive: false }));
document.addEventListener('contextmenu', (e) => { if (!e.target.closest('#blockly')) e.preventDefault(); });
const letGo = () => { for (const k in S.outs) S.outs[k] = [0, 0]; render(); };
window.addEventListener('blur', letGo);
document.addEventListener('visibilitychange', () => { if (document.hidden) { stopProgram(); letGo(); } else keepRunning(); });
setInterval(() => Link.send(), 500);                                       // heartbeat
setInterval(linkState, 500);
(function frame() { drawMotors(); requestAnimationFrame(frame); })();
render(); show(); Link.connect();
if (S.sub === 'advanced') loadBlockly().catch(() => {});